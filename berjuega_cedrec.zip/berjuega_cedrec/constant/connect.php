<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "ced_db";

try {
    $connect = new PDO("mysql:host=$servername;dbname=ced_db", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION);
 
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>