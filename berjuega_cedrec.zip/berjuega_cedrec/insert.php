<?php

require_once "./constant/connect.php";

if($_SERVER["REQUEST_METHOD"] === "POST"){
    $first_name = $_POST["firstname"];
    $middle_name = $_POST["middlename"];
    $last_name = $_POST["lastname"];
    $gender = $_POST["gender"];
    $birth_date = $_POST["birthdate"];
    $age = $_POST["age"];
    $user_name = $_POST["username"];
    $user_email = $_POST["email"];
    $password = $_POST["password"];
    try{
        $sql="INSERT INTO users (firstname,middlename,lastname,gender,birthdate,age,username,email,password) VALUES (:firstname,:middlename,:lastname,:gender,:birthdate,:age,:username,:email,:password)";
        $stmt = $connect->prepare($sql);
        $stmt->bindParam(':firstname',$first_name);
        $stmt->bindParam(':middlename',$middle_name);
        $stmt->bindParam(':lastname',$last_name);
        $stmt->bindParam(':gender',$gender);
        $stmt->bindParam(':birthdate',$birth_date);
        $stmt->bindParam(':age',$age);
        $stmt->bindParam(':username',$user_name);
        $stmt->bindParam(':email',$user_email);
        $stmt->bindParam(':password',$password);
        $stmt->execute();
        echo 1;
        //echo json_encode("status" => "success", "message" => "Data inserted successfully.")
        $conn=null;
    }catch(PDOException $e){
        echo"Error: ". $e->getMessage();
    }
}else{
    echo "Server error!";
}



?>