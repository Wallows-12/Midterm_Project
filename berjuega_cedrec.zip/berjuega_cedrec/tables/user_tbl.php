<?php
require_once "../index.html";
require_once "../constant/connect.php";

try {
    $sql = "CREATE TABLE IF NOT EXISTS users (
        user_id INT AUTO_INCREMENT  PRIMARY KEY, 
        firstname VARCHAR(50) NOT NULL,
        middlename VARCHAR(50) NOT NULL,
        lastname VARCHAR(50) NOT NULL,
        gender VARCHAR(50) NOT NULL,
        birthdate VARCHAR(50) NOT NULL,
        age INT(5) NOT NULL,
        username VARCHAR(50) NOT NULL,
        email VARCHAR(30) NOT NULL,
        password VARCHAR(50) NOT NULL
    )";

        $connect->exec($sql);

        echo 1;

} catch (PDOException $e) {
    echo "Error: ". $e->getMessage();
}

?>